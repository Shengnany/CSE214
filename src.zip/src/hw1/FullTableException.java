package hw1;
public class FullTableException extends Exception{
    FullTableException(){
        super("FullTableException");
    }
}

