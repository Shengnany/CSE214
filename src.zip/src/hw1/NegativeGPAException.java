package hw1;
public class NegativeGPAException extends Exception {
    NegativeGPAException () {
        super("Negative GPA");
    }
}