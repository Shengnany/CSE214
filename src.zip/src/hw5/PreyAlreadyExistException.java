package hw5;
public class PreyAlreadyExistException extends Exception {
    PreyAlreadyExistException(){
        super("PositionNotAvailableException");
    }
}
