
package hw5;
public class PositionNotAvailableException extends Exception {
    PositionNotAvailableException(){
        super("PositionNotAvailableException");
    }
}
