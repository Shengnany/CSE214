package hw5;
public class DietMismatchException extends Exception {
    DietMismatchException(){
        super("DietMismatchException");
    }
}
