package hw5;
public class IsPlantException extends Exception {
    IsPlantException(){
        super("IsPlantException");
    }
}
